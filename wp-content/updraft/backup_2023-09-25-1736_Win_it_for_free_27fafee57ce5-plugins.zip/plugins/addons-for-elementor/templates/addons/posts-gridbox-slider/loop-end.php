<?php
/**
 * Loop End - Posts Grid Box Slider Template
 *
 * This template can be overridden by copying it to mytheme/addons-for-elementor/addons/posts-gridbox-slider/loop-end.php
 *
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
?>
    </div><!-- .lae-posts-gridbox-slider -->

</div>