<?php
/**
 * Loop End - Posts Multislider Template
 *
 * This template can be overridden by copying it to mytheme/addons-for-elementor/addons/posts-multislider/loop-end.php
 *
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
?>
    </div><!-- .lae-posts-multislider -->

</div><!-- .lae-posts-multislider-wrap -->