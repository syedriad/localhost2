<?php
?>

<a class="lae-read-more" href="<?php echo get_the_permalink(); ?>"<?php echo $target; ?>><?php echo $read_more_text; ?></a>
